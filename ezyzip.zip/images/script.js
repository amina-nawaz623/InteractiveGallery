// Get all the image elements
const images = document.querySelectorAll('.card img');

// Add event listeners to each image
images.forEach((image) => {
  // Add hover effect to rotate the image
  image.addEventListener('mouseover', () => {
    image.style.transform = 'rotate(5deg)';
  });
  image.addEventListener('mouseout', () => {
    image.style.transform = 'rotate(0deg)';
  });

  // Add click event to view the image in a larger size
  image.addEventListener('click', () => {
    const imageUrl = image.src;
    const imageView = document.createElement('div');
    imageView.innerHTML = `
      <img src="${imageUrl}" style="width: 500px; height: 500px;">
    `;
    imageView.className = 'image-view';
    document.body.appendChild(imageView);
  });
});

// Add event listeners to each edit button
const editButtons = document.querySelectorAll('.btn-group button:nth-child(2)');
editButtons.forEach((editButton) => {
  editButton.addEventListener('click', () => {
    const cardBody = editButton.closest('.card-body');
    const editTextarea = document.createElement('textarea');
    editTextarea.value = cardBody.querySelector('p').textContent;
    cardBody.innerHTML = '';
    cardBody.appendChild(editTextarea);
  });
});

// Add transition effect to the section
const section = document.querySelector('.album');
section.style.opacity = 0;
setTimeout(() => {
  section.style.transition = 'opacity 1s';
  section.style.opacity = 1;
}, 1000);